#!/usr/bin/env python
"""SmallRhex_controller controller."""

# You may need to import some classes of the controller module. Ex:
#  from controller import Robot, Motor, DistanceSensor
from controller import Robot
from controller import Motor
from controller import InertialUnit
from controller import Gyro
from controller import Keyboard
from controller import Brake

from Motion import *
from panel import *
import os
import sys
import time
import math

# create the Robot instance.
robot = Robot()
TIME_STEP = int(robot.getBasicTimeStep())

# init sensors and drivers
gyro = robot.getGyro("gyro")
gyro.enable(TIME_STEP)
imu = robot.getInertialUnit("inertial unit")
imu.enable(TIME_STEP)
gps = robot.getGPS("gps")
gps.enable(TIME_STEP)
mKeyboard = Keyboard()  # 初始化键盘读入类
mKeyboard.enable(TIME_STEP)  # 以mTimeStep为周期从键盘读取

# You should insert a getDevice-like function in order to get the
# instance of a device of the robot. Something like:
#  motor = robot.getMotor('motorname')
#  ds = robot.getDistanceSensor('dsname')
#  ds.enable(timestep)

encoders = []  # joint motor encoders
encoder_names = [
    "left1_encoder",
    "left2_encoder",
    "left3_encoder",
    "right1_encoder",
    "right2_encoder",
    "right3_encoder",
]

motors = []  # joint motors
motor_names = [
    "left1_motor",
    "left2_motor",
    "left3_motor",
    "right1_motor",  # 3
    "right2_motor",
    "right3_motor",
]

for i in range(len(motor_names)):
    motors.append(robot.getMotor(motor_names[i]))
    encoders.append(motors[i].getPositionSensor())
    encoders[i].enable(TIME_STEP)
    motors[i].setPosition(0)  # enable velocity control

# brakes = []
# motors[4].enableTorqueFeedback(TIME_STEP)
# motors[5].enableTorqueFeedback(TIME_STEP)
# brakes.append(motors[4].getBrake())
# brakes.append(motors[5].getBrake())

# main loop
printed = False
panel = panel(gps, gyro, imu, motors, encoders, TIME_STEP)
walker = walking_controller(motors, panel)
climber = climbing_controller(motors, panel)
leg = leg_controller(motors, panel)

# Main loop:
# - perform simulation steps until Webots is stopping the controller
while robot.step(TIME_STEP) != -1:
    panel.sensor_update()
    TIME = robot.getTime()
    # checkFallen()
    # TODO 跌倒爬起
    # print("1")
    if printed == False:
        print("Press A into Mode 1: forward & backward, 3*2")
        print("Press B into Mode 2: up/downstairs, 2*3")
        print("Press C\into Mode 3: freely control each leg")
        #print("Press D into Mode 4: step testing, 3*2")
        print("Press R to reposition")
        printed = True
    key = mKeyboard.getKey()  # 从键盘读取输入
    ##################### Mode 1 ############################
    if key == 65:
        print("Into Mode 1\n"
              "Press W or S\n"
              "Press A or D to 调整相对位置\n"
              "Press Q to quit")
        walker.setOrigPos()
        robot.step(TIME_STEP * 100)
        # while (True):
        #     robot.step(TIME_STEP*10)
        #     panel.sensor_update()  # 每次计算都要刷新一下传感器，这两行绑定写
        #     print(panel.wheelVel[0])
        #     if panel.wheelVel[0]!=0:
        #         break
        walker.setVel(0)
        # key1 = -1
        while (True):
            robot.step(TIME_STEP)
            panel.sensor_update()
            key = mKeyboard.getKey()
            # print(key)
            if key == 81:  # QUIT
                printed = False
                break
            elif key == 87:
                walker.setVel(2)
            elif key == 83:
                walker.setVel(-2)
            # elif ((key != 87 and key != 83) and (key1 == 87 or key1 == 83)):
            #     #print('1', key)
            #
            elif key == 65:
                walker.setVel1(1, 3, 5, 2)
            elif key == 68:
                walker.setVel1(1, 3, 5, -2)
            else:
                walker.setVel(0)




            # key1 = key
        # else:
        #     walker.setVel(0)

    ##################### Mode 2 ############################
    # 缺点：一次只能控制一组
    if key == 66:
        print("Into Mode 2\n"
              "A:前两条腿；S：中间两条腿；D：后面两条腿\n"
              "Press Q to quit")
        climber.setOrigPos()
        robot.step(TIME_STEP * 100)
        walker.setVel(0)
        while (True):
            robot.step(TIME_STEP)
            panel.sensor_update()  # 每次计算都要刷新一下传感器，这两行绑定写
            key = mKeyboard.getKey()
            key1 = key
            if key == 81:  # QUIT
                printed = False
                break
            if key == 65:  # 前两条腿
                climber.setVel(0, 3, 5)
            else:
                climber.setVel(0, 3, 0)
            if key == 83:
                climber.setVel(1, 4, 5)
            else:
                climber.setVel(1, 4, 0)
            if key == 68:
                climber.setVel(2, 5, 5)
            else:
                climber.setVel(2, 5, 0)

    if key == 67:
        print("Into Mode 2\n"
              "S:左3；D：左2；F：左1----J:右1；K：右2；L:右3\n"
              "Press Q to quit")
        climber.setOrigPos()
        robot.step(TIME_STEP * 100)
        walker.setVel(0)
        while (True):
            robot.step(TIME_STEP)
            panel.sensor_update()  # 每次计算都要刷新一下传感器，这两行绑定写
            key = mKeyboard.getKey()
            key1 = key
            if key == 81:  # QUIT
                printed = False
                break
            if key == 70:  # 前两条腿
                leg.setVel(0, 2)
            else:
                leg.setVel(0, 0)
            if key == 68:  # 前两条腿
                leg.setVel(1, 2)
            else:
                leg.setVel(1, 0)
            if key == 83:  # 前两条腿
                leg.setVel(2, 2)
            else:
                leg.setVel(2, 0)
            if key == 74:  # 前两条腿
                leg.setVel(3, 2)
            else:
                leg.setVel(3, 0)
            if key == 75:  # 前两条腿
                leg.setVel(4, 2)
            else:
                leg.setVel(4, 0)
            if key == 76:  # 前两条腿
                leg.setVel(5, 2)
            else:
                leg.setVel(5, 0)

    if key == 82:  # 回到零点位置
        leg.setOrigPos()
        robot.step(TIME_STEP * 100)

    # Read the sensors:
    # Enter here functions to read sensor data, like:
    #  val = ds.getValue()

    # Process sensor data here.

    # Enter here functions to send actuator commands, like:
    #  motor.setPosition(10.0)
    # pass

# Enter here exit cleanup code.
