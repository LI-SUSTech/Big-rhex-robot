class walking_controller:
    def __init__(self, motors, panel):
        self.motors = motors
        self.panel = panel

    def setOrigPos(self):
        for i in range(0, 6):
            self.motors[i].setVelocity(float('inf'))
        self.motors[1].setPosition(3.14159)
        self.motors[3].setPosition(3.14159)
        self.motors[5].setPosition(3.14159)
        self.motors[0].setPosition(0)
        self.motors[2].setPosition(0)
        self.motors[4].setPosition(0)

    def setVel(self, Ev):  # TODO 倒着走会(Ev<0)出事情
        for i in range(0, 6):
            self.motors[i].setPosition(float('inf'))
            self.motors[i].setVelocity(Ev)
    def setVel1(self,i,j,k,Ev):
        for h in [i,j,k]:
            self.motors[h].setPosition(float('inf'))
            self.motors[h].setVelocity(Ev)


class climbing_controller:
    def __init__(self, motors, panel):
        self.motors = motors
        self.panel = panel

    def setOrigPos(self):
        for i in range(0, 6):
            self.motors[i].setVelocity(float('inf'))
        self.motors[1].setPosition(0)
        self.motors[3].setPosition(0)
        self.motors[5].setPosition(0)
        self.motors[0].setPosition(0)
        self.motors[2].setPosition(0)
        self.motors[4].setPosition(0)

    def setVel(self, i, j, Ev):
        for k in [i, j]:
            self.motors[k].setPosition(float('inf'))
            self.motors[k].setVelocity(Ev)


class leg_controller:
    def __init__(self, motors, panel):
        self.motors = motors
        self.panel = panel


    def setOrigPos(self):
        for i in range(0, 6):
            self.motors[i].setVelocity(float('inf'))
        self.motors[1].setPosition(0)
        self.motors[3].setPosition(0)
        self.motors[5].setPosition(0)
        self.motors[0].setPosition(0)
        self.motors[2].setPosition(0)
        self.motors[4].setPosition(0)

    def setVel(self, i, Ev):
        self.motors[i].setPosition(float('inf'))
        self.motors[i].setVelocity(Ev)
